class ThankYouController < ApplicationController
end
